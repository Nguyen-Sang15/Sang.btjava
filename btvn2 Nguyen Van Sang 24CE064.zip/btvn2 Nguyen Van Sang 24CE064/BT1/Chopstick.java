package BT2;

import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicInteger;

class Chopstick {
    private final Semaphore lock = new Semaphore(1);

    public boolean pickUp() {
        return lock.tryAcquire();
    }

    public void putDown() {
        lock.release();
    }
}

class Philosopher extends Thread {
    private int id;
    private Chopstick leftChopstick;
    private Chopstick rightChopstick;
    private Semaphore table;
    private static AtomicInteger count = new AtomicInteger(0); // Đếm số triết gia đã ăn

    public Philosopher(int id, Chopstick left, Chopstick right, Semaphore table) {
        this.id = id;
        this.leftChopstick = left;
        this.rightChopstick = right;
        this.table = table;
    }

    private void think() throws InterruptedException {
        System.out.println("Triết gia " + id + " đang suy nghĩ...");
        Thread.sleep((long) (Math.random() * 1000));
    }

    private void eat() throws InterruptedException {
        System.out.println("Triết gia " + id + " đang ăn 🍜...");
        Thread.sleep((long) (Math.random() * 1000));
    }

    @Override
    public void run() {
        try {
            while (count.get() < 5) {
                think();
                table.acquire();

                if (leftChopstick.pickUp()) {
                    System.out.println("Triết gia " + id + " lấy đũa trái");
                    if (rightChopstick.pickUp()) {
                        System.out.println("Triết gia " + id + " lấy đũa phải và bắt đầu ăn");
                        eat();

                        rightChopstick.putDown();
                        System.out.println("Triết gia " + id + " trả đũa phải");

                        leftChopstick.putDown();
                        System.out.println("Triết gia " + id + " trả đũa trái");

                        synchronized (Philosopher.class) {
                            if (count.get() < 5) {
                                count.incrementAndGet();
                            }
                        }
                    } else {
                        leftChopstick.putDown();
                    }
                }

                table.release();
            }
        } catch (InterruptedException e) {
            System.out.println("Lỗi tại triết gia " + id + ": " + e.getMessage());
        }
    }
}





