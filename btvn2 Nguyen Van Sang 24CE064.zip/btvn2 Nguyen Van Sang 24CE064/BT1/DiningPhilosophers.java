package BT2;

import java.util.concurrent.Semaphore;

public class DiningPhilosophers {
    public static void main(String[] args) throws InterruptedException {
        int numPhilosophers = 5;
        Philosopher[] philosophers = new Philosopher[numPhilosophers];
        Chopstick[] chopsticks = new Chopstick[numPhilosophers];

        for (int i = 0; i < numPhilosophers; i++) {
            chopsticks[i] = new Chopstick();
        }

        Semaphore table = new Semaphore(numPhilosophers - 1);

        for (int i = 0; i < numPhilosophers; i++) {
            philosophers[i] = new Philosopher(i, chopsticks[i], chopsticks[(i + 1) % numPhilosophers], table);
            philosophers[i].start();
        }
        for (Philosopher p : philosophers) {
            p.join();
        }

        System.out.println("\nKết thúc");
    }
}